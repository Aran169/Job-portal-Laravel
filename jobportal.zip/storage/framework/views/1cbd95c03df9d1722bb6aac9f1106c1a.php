

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($job->title); ?></h1>
    <p><strong>Description:</strong> <?php echo e($job->description); ?></p>
    <p><strong>Location:</strong> <?php echo e($job->location); ?></p>
    <p><strong>Salary:</strong> Rs.<?php echo e(number_format($job->salary, 2)); ?></p>

    <?php if(auth()->guard()->check()): ?>
        <form action="<?php echo e(route('jobs.apply', $job->id)); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-success">Apply for this Job</button>
        </form>
        <?php if($hasApplied): ?>
    <p>You have already applied to this job.</p>

<?php endif; ?>


    <?php else: ?>
        <p class="alert alert-warning">Please <a href="<?php echo e(route('login')); ?>">login</a> to apply for this job.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MVC\job-portal\resources\views/jobs/show.blade.php ENDPATH**/ ?>