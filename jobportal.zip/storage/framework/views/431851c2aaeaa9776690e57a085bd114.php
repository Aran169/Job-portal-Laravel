

<?php $__env->startSection('content'); ?>
    <h1>Edit Job: <?php echo e($job->title); ?></h1>

    <form action="<?php echo e(route('admin.jobs.update', $job->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Job Title</label>
            <input type="text" name="title" id="title" class="form-control" value="<?php echo e($job->title); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Job Description</label>
            <textarea name="description" id="description" class="form-control" required><?php echo e($job->description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="location">Location</label>
            <input type="text" name="location" id="location" class="form-control" value="<?php echo e($job->location); ?>" required>
        </div>
        <div class="form-group">
            <label for="salary">Salary</label>
            <input type="number" name="salary" id="salary" class="form-control" step="0.01" value="<?php echo e($job->salary); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Job</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MVC\job-portal\resources\views/admin/edit.blade.php ENDPATH**/ ?>