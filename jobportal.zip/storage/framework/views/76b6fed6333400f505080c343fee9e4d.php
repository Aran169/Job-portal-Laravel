

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Admin Dashboard</h1>
    <a href="<?php echo e(route('admin.jobs.create')); ?>" class="btn btn-primary mb-3">Post New Job</a>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Location</th>
                <th>Salary</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($job->id); ?></td>
                    <td><?php echo e($job->title); ?></td>
                    <td><?php echo e($job->location); ?></td>
                    <td><?php echo e($job->salary); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.jobs.edit', $job->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('admin.jobs.destroy', $job->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this job?');">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MVC\job-portal\resources\views/admin/index.blade.php ENDPATH**/ ?>