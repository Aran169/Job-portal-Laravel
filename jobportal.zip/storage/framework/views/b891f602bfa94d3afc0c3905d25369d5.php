

<?php $__env->startSection('content'); ?>
    <h3>My Applied Jobs</h3>

    <?php if($appliedJobs->isEmpty()): ?>
        <p>No jobs applied yet.</p>
    <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $appliedJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appliedJob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($appliedJob->job->title); ?></h5>
                            <p class="card-text"><?php echo e(Str::limit($appliedJob->job->description, 100)); ?></p>
                            <p class="card-text"><strong>Location:</strong> <?php echo e($appliedJob->job->location); ?></p>
                            <p class="card-text"><strong>Salary:</strong> Rs. <?php echo e(number_format($appliedJob->job->salary, 2)); ?></p>
                            <a href="<?php echo e(route('jobs.show', $appliedJob->job->id)); ?>" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MVC\job-portal\resources\views/jobs/applied.blade.php ENDPATH**/ ?>